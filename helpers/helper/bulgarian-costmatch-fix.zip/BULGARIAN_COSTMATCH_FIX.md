# Bulgarian KCC matcher fix

This patches the actual ERP backend supplied in your bundle, not the standalone matcher prototype. No LLM, model server or API key is required. Bulgarian rows bypass optional embedding retrieval and semantic-model checks.

## What changed

- Interpret the primary object, operation bundle, scope, material, work location, dimensions/specifications and included/excluded work before trusting a price.
- Contradictions veto a match. Missing requirements remain review evidence, not BOQ money.
- Numeric fragments cannot create semantic confidence or retrieve candidates by themselves.
- Structural distribution/header rows bypass pricing; stale auto-written amounts are cleared.
- An area rate cannot answer a volume row. Genuine exact learned volume rulings remain usable.
- The `opr` base includes UUID-shaped operator rulings.
- Price disagreement is checked across equivalent unit spellings, including `м²` and `кв.м.`.
- The offline runner writes only an actual operator quotation, converted to the query unit and EUR. It never creates a price by averaging quotes.

## Results on your supplied files

- Fresh offline retrieval and matching: 87,751 CSV records scanned; 3,964 active, positive, EUR/BGN operator-origin records available for pricing.
- 535 work rows: 345 exact quoted prices, 188 review rows and 2 unmatched rows. Review/unmatched money remains blank.
- All 19 highlighted bad positions remain unpriced, including the structural rows.
- Learned brickwork ruling `OPR-4e9b7725-aac7-4542-b2fb-350c2cda8e63` remains 8 EUR/m³, yielding 48 EUR for 6 m³.
- 129 focused tests pass. Focused Ruff, parser mypy and syntax compilation pass.

These counts are NOT a correctness benchmark for the other 345 prices: no independently corrected reference workbook was supplied. The offline CSV lacks DB metadata, translated descriptions, bill aliases and pattern priors. This is a real fresh offline run, not a PostgreSQL/service integration run. PostgreSQL integration tests are included but were not executed here.

## Apply safely (PowerShell)

Use the Python environment you normally use for your ERP backend. Stop the backend before applying the patch and restart it afterward. The backend directory must contain `app` and `pyproject.toml`.

```powershell
$backend = Read-Host 'Full path to your ERP backend directory'
$patch = Read-Host 'Full path to the downloaded bulgarian-costmatch-fix.patch'
Push-Location -LiteralPath $backend
try {
    git apply --no-index --check "$patch"
    if ($LASTEXITCODE -ne 0) { throw 'Patch does not fit this backend version. Nothing was applied.' }
    git apply --no-index "$patch"
    if ($LASTEXITCODE -ne 0) { throw 'Patch application failed. Do not restart until the error is resolved.' }
    python -m pytest --confcutdir=tests/unit tests/unit/test_cost_match_matcher.py tests/unit/cost_match -q --tb=short
    if ($LASTEXITCODE -ne 0) { throw 'Matcher tests failed.' }
}
finally { Pop-Location }
```

The ZIP also contains the replacement files at their backend-relative paths. Do not blindly overwrite a newer backend; the checked patch is safer. No database migrations or corpus imports are included.

## Reproduce the offline workbook

From the patched backend directory:

```powershell
$corpus = Read-Host 'Full path to cost_items.csv'
$inputBook = Read-Host 'Full path to kcc2-INPUT.xlsx'
$outputBook = Read-Host 'Full path for the NEW output workbook'
python scripts/kcc_match_bg.py --corpus "$corpus" --input "$inputBook" --output "$outputBook"
```

This runner uses the supplied KCC2 layout: A=position, B=description, C=unit, D=quantity, E=unit rate, F=total. It preserves existing nonblank rates and refuses to overwrite the input. Its `BG_MATCH_AUDIT` sheet records parsed identity, decision, source quotation, reasons and alternatives.

The parser has a finite construction vocabulary. Unknown wording and missing specifications stay unresolved; do not loosen these gates merely to increase the number of priced rows. Expand vocabulary and test it against real equivalent/non-equivalent examples instead. Keep the ERP's existing LICENSE and NOTICE.
