"""Deterministic Bulgarian work identity, independent of lexical confidence."""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal
from functools import lru_cache


_BG = re.compile(r"[А-Яа-я]")
_HEADER = re.compile(
    r"^(?:смр\s*[-–:]?\s*разпределение\b|разпределение\s+кота\b|"
    r"(?:част|раздел|глава|подраздел)\s*[:\d]|(?:общо|всичко|междинна сума)\b|"
    r"строително[- ]монтажни работи\s*$)", re.I,
)
_TAIL = re.compile(r"\b(?:вкл\.?|включително|включва\w*|съгласно)\b", re.I)
_EXCLUDE = re.compile(r"\b(?:без|не\s+включва\w*)\b([^.;]*)", re.I)
_BOILERPLATE = frozenset(
    "вкл включително включва съгласно всички свързани свързаните с със това разходи "
    "разходите изисквания изискванията на за и от тс техническата спецификация "
    "техническите спецификации крайна цена крайната цената".split()
)
_OPERATIONS = (
    ("demolish", r"\b(?:демонтаж|демонтиране|разваляне|разрушаване|къртене|разбиване|премахване)\b"),
    ("install", r"\b(?:монтаж|монтиране|направа|изпълнение|изработка|изграждане|полагане|"
                r"поставяне|зидане|иззиждане|засаждане|засяване|бетониране|"
                r"боядисване|боядисвене|лакиране|шпакловане|измазване|облицоване)\b"),
    ("repair", r"\b(?:ремонт|ремонтиране|поправка|възстановяване|преработка)\b"),
    ("haul", r"\b(?:извозване|транспортиране|превозване|превоз|транспорт)\b"),
    ("test", r"\b(?:изпитване|тестване|измерване|наладка|пускане)\b"),
    ("clean", r"\b(?:почистване|измиване|промиване|обезпрашаване)\b"),
    ("prime", r"\b(?:грундиране|грундира|грунд)\b"),
    ("excavate", r"\b(?:изкоп|изкопаване)\b"),
    ("backfill", r"\b(?:засипване|обратен насип|засипка)\b"),
)
_OP_RES = tuple((value, re.compile(pattern, re.I)) for value, pattern in _OPERATIONS)

# Each noun phrase names a priced entity, not merely a related trade.
_OBJECTS = (
    ("formwork", r"\bкофраж\w*"),
    ("masonry", r"\b(?:тухл\w*(?:\s+зид\w*)?|зидари\w*|зид\w*|газобетон\w*)"),
    ("plaster", r"\b(?:(?:варов\w*|вароцимент\w*|гипсов\w*|цимент\w*)\s+)?мазилк\w*"),
    ("putty", r"\b(?:(?:гипсов\w*|цимент\w*)\s+)?шпаклов\w*"),
    ("paint", r"\b(?:латекс\w*|боя\b|боядис\w*)"),
    ("concrete_floor", r"\b(?:шлайфан\w*\s+)?бетон(?:ов|н)\w*\s+настилк\w*"),
    ("ramp", r"\b(?:бетон(?:ов|н)\w*\s+)?рамп\w*"),
    ("screed", r"\b(?:(?:цимент\w*|бетонов\w*)\s+)?замазк\w*"),
    ("concrete_slab", r"\b(?:стоманобетонов\w*|бетонов\w*)\s+плоч\w*"),
    ("concrete", r"\bбетон\b"),
    ("granite_stairs", r"\bгранит\s*[- ]?\s*стълб\w*"),
    ("reinforcement", r"\b(?:арматур\w*|армиров\w*)"),
    ("fan", r"\b(?:(?:кръгъл|канален|кръгъл канален)\s+)?вентилатор\w*"),
    ("duct", r"\b(?:(?:кръгъл|спирален|правоъгълен)\s+)?въздуховод\w*"),
    ("strainer", r"\bмрежест\w*\s+филтър\w*"),
    ("filter", r"\bфилтър\w*"),
    ("diffuser", r"\b(?:конусен\s+смукател\w*|дифузер\w*|анемостат\w*)"),
    ("treatment_plant", r"\b(?:(?:локално|биологично)\s+)?пречиствател\w*\s+(?:съоръжение|станция)"),
    ("pump", r"\b(?:(?:циркулационн\w*|електронн\w*|потопяем\w*)\s+)*помп\w*"),
    ("plant", r"\b(?:калистемон\w*|callistemon|pinus|храст\w*|дървет\w*|растителност\w*|трев\w*)"),
    ("fastener", r"\b(?:крепеж\w*|скоб\w*|анкер\w*|дюбел\w*)"),
    ("control", r"\b(?:управление|контролер\w*|термостат\w*)"),
    ("sensor", r"\b(?:датчик\w*|сензор\w*)"),
    ("valve", r"\b(?:(?:спирател\w*|сферич\w*|обрат\w*|баланс\w*|регулиращ\w*)\s+)?(?:кран\w*|вентил\w*|клапан\w*)"),
    ("pipe", r"\b(?:тръб\w*|водопровод\w*)"),
    ("elbow", r"\b(?:коляно\w*|колена)"),
    ("tee", r"\bтроиник\w*"),
    ("coupling", r"\b(?:муфа\w*|муфи|холендер\w*)"),
    ("reducer", r"\b(?:редук\w*|преходник\w*)"),
    ("collector", r"\bколектор\w*"),
    ("water_meter", r"\bводомер\w*"),
    ("toilet", r"\b(?:тоалетн\w*\s+чини\w*|моноблок\w*)"),
    ("basin", r"\b(?:умивалник\w*|мивк\w*)"),
    ("siphon", r"\bсифон\w*"),
    ("radiator", r"\bрадиатор\w*"),
    ("convector", r"\bконвектор\w*"),
    ("boiler", r"\bбоилер\w*"),
    ("chiller", r"\bчилър\w*"),
    ("air_conditioner", r"\b(?:климатик\w*|климатизатор\w*)"),
    ("heat_pump", r"\bтермопомп\w*"),
    ("door", r"\b(?:врат\w*|входна\s+врат\w*)"),
    ("window", r"\b(?:дограма\w*|прозор\w*|витрин\w*)"),
    ("drywall", r"\bгипсокартон\w*"),
    ("skylight", r"\b(?:оберлихт\w*|капандур\w*)"),
    ("ceiling", r"\bокачен\w*\s+таван\w*"),
    ("board", r"\b(?:osb|шперплат\w*|мдф|mdf|пдч|плоскост\w*)\b"),
    ("cladding", r"\b(?:(?:дъсчен\w*|металн\w*)\s+)?обшивк\w*"),
    ("vapour_barrier", r"\b(?:пароизолацион\w*\s+фолио|пароизолаци\w*)"),
    ("profile", r"\b(?:металн\w*\s+)?профил\w*"),
    ("mesh", r"\b(?:(?:армиров\w*|армиращ\w*|стоманен\w*)\s+)?мреж\w*"),
    ("curb", r"\bбордюр\w*"),
    ("tiling", r"\b(?:теракот\w*|фаянс\w*|гранитогрес\w*|плочк\w*)"),
    ("insulation", r"\b(?:топлоизола\w*|изолац\w*|eps\b|xps\b|минералн\w*\s+ват\w*)"),
    ("waterproofing", r"\b(?:хидроизола\w*|битум\w*\s+мембран\w*)"),
    ("geotextile", r"\bгеотекстил\w*"),
    ("geogrid", r"\bгеомреж\w*"),
    ("cable", r"\b(?:кабел\w*|проводник\w*)"),
    ("panel", r"\b(?:табло\w*|разпределител\w*\s+табл\w*)"),
    ("switchgear", r"\b(?:прекъсвач\w*|предпазител\w*)"),
    ("luminaire", r"\b(?:осветител\w*|ламп\w*|плафон\w*|прожектор\w*)"),
    ("socket", r"\b(?:контакт\w*|розетк\w*)"),
    ("switch", r"\b(?:електрически\s+)?ключ\w*"),
    ("camera", r"\bкамер\w*"),
    ("earthwork", r"\b(?:изкоп\w*|насип\w*)"),
    ("roof_tile", r"\bкеремид\w*"),
    ("gutter", r"\b(?:улук\w*|улуц\w*|водосточн\w*)"),
    ("railing", r"\b(?:парапет\w*|ограда\w*|ограждение\w*)"),
)
_OBJECT_RES = tuple((value, re.compile(pattern, re.I)) for value, pattern in _OBJECTS)
_MATERIALS = (
    ("lime_cement", r"\bвароцимент\w*"),
    ("lime", r"\b(?:варов\w*|вар\b)"),
    ("gypsum", r"\bгипс\w*"),
    ("cement", r"\bцимент\w*"),
    ("pvc", r"\bpvc\b|\bпвц\b"),
    ("pe", r"\b(?:pe|hdpe|полиетилен\w*)\b"),
    ("ppr", r"\b(?:ppr|полипропилен\w*)\b"),
    ("copper", r"\b(?:меден\w*|медни|медна|медта)\b"),
    ("steel", r"\b(?:стоман\w*|поцинкован\w*)"),
    ("aluminium", r"\b(?:алумини\w*|ал\s*\.)"),
    ("wood", r"\b(?:дървен\w*|дървес\w*|дъсчен\w*)"),
    ("concrete", r"\b(?:бетон\w*|стоманобетон\w*)"),
)
_MATERIAL_RES = tuple((value, re.compile(pattern, re.I)) for value, pattern in _MATERIALS)


def is_structural(text: str | None) -> bool:
    return bool(_HEADER.search((text or '').strip()))


def identity_text(text: str | None) -> str:
    from app.modules.cost_match.matcher import normalize_text

    norm = normalize_text(text)
    norm = re.sub(r"\s+краина цена\s*$", "", norm)
    marker = _TAIL.search(norm)
    if marker and set(norm[marker.start():].split()) <= _BOILERPLATE:
        norm = norm[:marker.start()].strip()
    return norm


@dataclass(frozen=True)
class WorkIdentity:
    object: str | None
    operations: frozenset[str]
    scope: str | None
    materials: frozenset[str]
    specs: tuple[tuple[str, frozenset[str]], ...]
    tail: frozenset[str]
    excluded: frozenset[str]
    locations: frozenset[str]


def _number(value: str) -> str:
    return format(Decimal(value.replace(',', '.')).normalize(), 'f')


@lru_cache(maxsize=32768)
def parse_work(text: str) -> WorkIdentity:
    from app.modules.cost_match.matcher import (
        _GENERIC_TERMS, _PROCESS_CONCEPTS, canonical_tokens, extract_specs, fold_accents,
    )

    norm = fold_accents(text.replace('∅', 'ф').replace('Ø', 'ф').replace('ø', 'ф')).lower()
    marker = _TAIL.search(norm)
    main = norm[:marker.start()] if marker else norm
    entities = [(m.start(), i, value) for i, (value, pattern) in enumerate(_OBJECT_RES)
                if (m := pattern.search(main))]
    obj = min(entities)[2] if entities else None
    exclusions = list(_EXCLUDE.finditer(norm))
    positive = norm
    for match in reversed(exclusions):
        positive = positive[:match.start()] + ' ' + positive[match.end():]
    operations = {value for value, pattern in _OP_RES if pattern.search(positive)}
    if 'install' in operations and re.search(r"\b(?:обратен|обратно|повторен|повторно)\b.{0,20}\bмонтаж", norm):
        operations.remove('install')
        operations.add('reinstall')
    supply = bool(re.search(r"\bдоставка\b", norm))
    no_supply = bool(re.search(r"\b(?:без\s+(?:доставка|материал\w*)|само\s+труд|труд\s+само)\b", norm))
    work = bool(operations)
    scope = 'labour' if no_supply else 'supply_install' if supply and work else 'material' if supply else None
    materials = {value for value, pattern in _MATERIAL_RES if pattern.search(main)}
    specs = extract_specs(text.replace('∅', 'ф').replace('Ø', 'ф').replace('ø', 'ф'))
    # Inch punctuation is semantic. Backticks and doubled apostrophes are
    # common Bulgarian workbook spellings of the inch mark.
    inches = re.compile(r"(?<!\w)(?:[фФ∅Øø]|DN\s*)?\s*(\d+(?:[.,]\d+)?(?:\s+\d+/\d+|/\d+)?)\s*(?:\"|″|``|''|инч\w*)", re.I)
    for match in inches.finditer(text):
        value = match.group(1).replace(',', '.')
        if ' ' in value.strip():
            whole, fraction = value.split()
            numerator, denominator = fraction.split('/')
            if not Decimal(denominator):
                continue
            number = Decimal(whole) + Decimal(numerator) / Decimal(denominator)
        elif '/' in value:
            numerator, denominator = value.split('/')
            if not Decimal(denominator):
                continue
            number = Decimal(numerator) / Decimal(denominator)
        else:
            number = Decimal(value)
        specs.setdefault('inch_connection', set()).add(format(number.normalize(), 'f'))
    for cls, pattern in (
        ('flow_m3h', r"(\d+(?:[.,]\d+)?)\s*[mм](?:3|³)\s*/\s*(?:h|ч)\b"),
        ('flow_m3d', r"(\d+(?:[.,]\d+)?)\s*[mм](?:3|³)\s*/\s*(?:d|ден|д)\b"),
        ('pressure_pa', r"(\d+(?:[.,]\d+)?)\s*pa\b"),
        ('wattage', r"(\d+(?:[.,]\d+)?)\s*(?:w|вт)\b"),
        ('voltage', r"(\d+(?:[.,]\d+)?)\s*(?:v|в)\b"),
        ('protection_ip', r"\bip\s*(\d+)\b"),
    ):
        for match in re.finditer(pattern, text, re.I):
            specs.setdefault(cls, set()).add(_number(match.group(1)))
    tail = set()
    if marker:
        tail_text = norm[marker.end():]
        if not set(identity_text(tail_text).split()) <= _BOILERPLATE:
            tail = set(canonical_tokens(tail_text)) - _PROCESS_CONCEPTS - _GENERIC_TERMS
    excluded = set().union(*(set(canonical_tokens(m.group(1))) - _PROCESS_CONCEPTS - _GENERIC_TERMS
                             for m in exclusions))
    locations = {value for value, pattern in (
        ('wall', r'\b(?:по|на)\s+стен\w*'),
        ('ceiling', r'\b(?:по|на)\s+таван\w*'),
        ('floor', r'\b(?:по|на)\s+под\w*'),
        ('column', r'\b(?:по|на)\s+колон\w*'),
        ('roof', r'\b(?:по|на)\s+покрив\w*'),
    ) if re.search(pattern, main)}
    return WorkIdentity(obj, frozenset(operations), scope, frozenset(materials),
                        tuple(sorted((k, frozenset(v)) for k, v in specs.items())), frozenset(tail),
                        frozenset(excluded), frozenset(locations))


def compare_work(query: str, candidate: str) -> tuple[list[str], list[str]]:
    """Return contradictions and missing evidence separately; neither is identity."""
    q, c = parse_work(query), parse_work(candidate)
    conflicts: list[str] = []
    missing: list[str] = []
    if q.object and c.object and q.object != c.object:
        conflicts.append(f'work_object_conflict:{q.object}:{c.object}')
    elif not q.object or not c.object:
        missing.append('work_object_unknown')
    if q.operations != c.operations:
        if q.operations and c.operations:
            conflicts.append('work_operation_bundle_conflict')
        else:
            missing.append('work_operation_unknown')
    if q.scope and c.scope and q.scope != c.scope:
        conflicts.append(f'work_scope_conflict:{q.scope}:{c.scope}')
    elif q.scope != c.scope:
        missing.append('work_scope_unknown')
    if q.materials and c.materials and q.materials.isdisjoint(c.materials):
        conflicts.append('work_material_conflict')
    elif q.materials != c.materials:
        missing.append('work_material_incomplete')
    if q.locations and c.locations and q.locations.isdisjoint(c.locations):
        conflicts.append('work_location_conflict')
    elif q.locations != c.locations:
        missing.append('work_location_incomplete')
    q_specs, c_specs = dict(q.specs), dict(c.specs)
    for cls in q_specs.keys() | c_specs.keys():
        q_values, c_values = q_specs.get(cls, frozenset()), c_specs.get(cls, frozenset())
        if q_values and c_values and q_values.isdisjoint(c_values):
            conflicts.append(f'work_spec_conflict:{cls}')
        elif q_values != c_values:
            missing.append(f'work_spec_incomplete:{cls}')
    if q.tail != c.tail:
        missing.append('work_inclusions_incomplete')
    if q.excluded != c.excluded:
        missing.append('work_exclusions_incomplete')
    if q.excluded & c.tail or c.excluded & q.tail:
        conflicts.append('work_exclusions_conflict')
    return conflicts, missing


def is_bulgarian(text: str) -> bool:
    return bool(_BG.search(text))
